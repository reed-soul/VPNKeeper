import { setupEventListeners } from './events';

document.addEventListener('DOMContentLoaded', async () => {
  await setupEventListeners();
}); 